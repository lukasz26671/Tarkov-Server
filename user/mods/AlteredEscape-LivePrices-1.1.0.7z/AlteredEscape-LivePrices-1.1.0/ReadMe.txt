
Mod Information:
This mod will change the current Flea and trader prices to match this weeks average live price per item.

the mod has an auto update feature, the live prices will be updated every Sunday at 12pm (UTC+1)
this will automatically pull the latest information every 7 days.

to sync your prices, you must delete the file /src/nextUpdated.json on Sunday ( you only need to do this once, it will then automatically update at that same time the following sunday )
if you do not sync your prices they will still be updated every 7 days.
syncing only means that your prices will be the latest for that week.


Mod Changes:
1.1.0: 
Added code to update the traders assort files to allow the traders to sell items at the latest live price.