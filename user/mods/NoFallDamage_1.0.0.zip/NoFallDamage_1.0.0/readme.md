Made By TheMaoci

## Info
The mod does the following:
- examine all items by editing cached items.json file