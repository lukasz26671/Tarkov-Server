# Nehax-MagazineManiac-1.0.0

A bunch of scripts to customize magazine related stuff for JET-12.12 - bad santa & Altered Escape 2.1.0

## Features 
* FastLoading - Let you customize the magazine loading speed by applying a multiplier to the default value.
* MagazineCapacity - Let you change a magazine ammo capacity.

## Installation
* stop the server
* extract files inside your mod directory
* clear server cache
* start server

## MagazineCapacity usage
* find the id of the magazine you want to customize
* add it in config.json, type your new capacity (numeric value only) and enable it (true) (copy paste the template)
* launch server and voilà 

## Planned features
* magazine customization (slot size, ammo types...)

