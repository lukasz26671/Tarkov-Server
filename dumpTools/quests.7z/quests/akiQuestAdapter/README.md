# AKI Quests Adapter
Takes a dump from our **friendly neighbours** and converts it to our quests template, ready to be used in db/quests.
