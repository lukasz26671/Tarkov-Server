# Check Missing Quests
Takes a dump **previously downloaded from [TarkovTracker](https://raw.githack.com/TarkovTracker/tarkovdata/master/quests.json)** and lists the missing quests from the given quests.json file at root.
